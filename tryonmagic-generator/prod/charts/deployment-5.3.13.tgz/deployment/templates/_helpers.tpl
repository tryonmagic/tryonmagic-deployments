{{/*
Get container port by name
*/}}
{{- define "deployment.container.port" -}}
{{- $root := index . 0 -}}
{{- $portName := index . 1 -}}
{{- range $root.Values.container.ports -}}
{{- if eq .name $portName -}}
{{- .port -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "deployment.health_check" -}}
{{- $root := index . 0 -}}
{{- $type := index . 1 -}}
{{- $health := $root.Values.health_check -}}

{{/* Debug prints as YAML comments */}}
{{- printf "# DEBUG: type=%s" $type | nindent 0 }}
{{- printf "# DEBUG: health=%v" $health | nindent 0 }}

{{- $portType := "http" -}}
{{- $endpoint := "/health" -}}

{{/* Fix for true map instead of on */}}
{{- if $health.true -}}
{{- $portType = $health.true.port.name | default "http" -}}
{{- $endpoint = $health.true.endpoint | default "/health" -}}
{{- end -}}

{{- if eq $portType "grpc" }}
grpc:
  port: {{ include "deployment.container.port" (list $root "grpc") | default 8081 }}
  service: {{ $endpoint }}
{{- else }}
httpGet:
  path: {{ $endpoint }}
  port: {{ include "deployment.container.port" (list $root $portType) | default 8080 }}
{{- end }}
failureThreshold: 3
initialDelaySeconds: {{ get (get $health $type) "delay" | default 30 | atoi }}
periodSeconds: {{ get (get $health $type) "period" | default 10 | atoi }}
successThreshold: 1
timeoutSeconds: 1
{{- end -}}


{{/*
Get health check annotation for ALB
*/}}
{{- define "deployment.health.annotation" -}}
{{- $root := . -}}
{{- $health := .Values.health_check -}}

{{/* Debug prints as YAML comments */}}
{{- printf "# DEBUG: health_check.enabled=%v (type: %T)" $health.enabled $health.enabled | nindent 0 }}
{{- printf "# DEBUG: health_check.true=%v (type: %T)" $health.true $health.true | nindent 0 }}
{{- printf "# DEBUG: full health_check=%v (type: %T)" $health $health | nindent 0 }}

{{- if and $health.enabled $health.true }}
{{- if eq $health.true.port.name "http" }}
alb.ingress.kubernetes.io/healthcheck-path: {{ $health.true.endpoint }}
{{- end }}
{{- end }}
{{- end -}}